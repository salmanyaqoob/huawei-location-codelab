package com.android.huawei_location_demo

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.View
import androidx.core.app.ActivityCompat
import com.huawei.hmf.tasks.Task
import com.huawei.hms.common.ApiException
import com.huawei.hms.common.ResolvableApiException
import com.huawei.hms.location.*
import kotlinx.android.synthetic.main.activity_main.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity(), View.OnClickListener {

    companion object {
        private const val TAG = "LocationUpdatesCallback"
        private var LocationLog: String = ""
    }

    val PERMISSIONS = arrayOf(
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
    )

    // the callback of the request
    private var mLocationCallback: LocationCallback? = null

    private var mLocationRequest: LocationRequest? = null

    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    private lateinit var settingsClient: SettingsClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_location_update.setOnClickListener(this)
        btn_location_update_remove.setOnClickListener(this)

        // TODO: 1.5 Create a location provider client and device setting client


        // TODO: 1.6 Create a location request.


        // Register LocationCallback
        registerLocationCallback()

        // check location permission
        if (!hasLocationPermission()) requestLocationPermission()

    }

    // check location permission
    private fun requestLocationPermission() {
        // TODO: 1.3 check location permission

    }

    // TODO: 1.4 Permission result callback to application
    override fun onRequestPermissionsResult(
            requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

    }

    /**
     * Determine if you have the location permission
     */
    private fun hasLocationPermission(): Boolean {
        for (permission in PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(
                            this,
                            permission
                    ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }
        return true
    }

    /**
     * Register LocationCallback to get Location Updates
     */
    private fun registerLocationCallback() {
        // TODO: 1.7  Register LocationCallback to get Location Updates
        
    }


    /**
     * function：Requests location updates with a callback on the specified Looper thread.
     * first：use SettingsClient object to call checkLocationSettings(LocationSettingsRequest locationSettingsRequest) method to check device settings.
     * second： use  FusedLocationProviderClient object to call requestLocationUpdates (LocationRequest request, LocationCallback callback, Looper looper) method.
     */
    // TODO: 1.8  Requests location updates with a callback on the specified Looper thread.
    private fun requestLocationUpdatesWithCallback() {

    }

    /**
     * remove the request with callback
     */
    // TODO: 1.9  Remove the Location request with callback
    private fun removeLocationUpdatesWithCallback() {

    }

    /**
     * onDestroy remove location update
     */
    override fun onDestroy() {
        // don't need to receive callback
        removeLocationUpdatesWithCallback()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 0) {
            when (resultCode) {
                Activity.RESULT_OK -> {
                    Log.d(TAG, "User confirm to access location")
                    requestLocationUpdatesWithCallback()
                }
                Activity.RESULT_CANCELED -> {
                    Log.d(TAG, "User denied to access location")
                }
            }
        }
    }

    override fun onClick(v: View) {
        try {
            when (v.id) {
                R.id.btn_location_update -> requestLocationUpdatesWithCallback()
                R.id.btn_location_update_remove -> removeLocationUpdatesWithCallback()
            }
        } catch (e: Exception) {
            Log.e(TAG, "RequestLocationUpdatesWithCallbackActivity Exception:$e")
            makeLocationLog("RequestLocationUpdatesWithCallbackActivity Exception:$e")
        }
    }

    private fun makeLocationLog(log: String) {
        LocationLog = LocationLog + log + "\n"
        tv_location_result.text = LocationLog
    }

}