package com.android.geofencedemo.utils

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.google.android.gms.tasks.Task
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*


/**
 * Wrapper class for handling Location related methods
 */
class GoogleLocationManager constructor(private val context : Context) {
    val TAG = "Google_Location"

    companion object {
        const val REQUEST_CHECK_SETTINGS = 123
        const val REQUEST_ENABLE_GPS = 456
    }

}