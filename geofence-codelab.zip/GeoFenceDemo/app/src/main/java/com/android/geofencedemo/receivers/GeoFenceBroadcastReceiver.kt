package com.android.geofencedemo.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.android.geofencedemo.services.GeofenceIntentService

// TODO: 1.4 Create GeoFenceBroadcastReceiver Broadcast Receiver
class GeoFenceBroadcastReceiver : BroadcastReceiver() {
    private val TAG = "geod Geofence"

    override fun onReceive(context: Context, intent: Intent) {
        Log.i(TAG, "GeoFenceBroadcastReceiver ()")
    }
}
