package com.android.geofencedemo.services

import android.app.IntentService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.text.TextUtils
import android.util.Log
import androidx.core.app.JobIntentService
import androidx.core.app.NotificationCompat
import androidx.core.app.TaskStackBuilder
import com.android.geofencedemo.MainActivity
import com.android.geofencedemo.R
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

// TODO: 1.3 Create GeofenceIntentService extends with JobIntentService and define override methods
class GeofenceIntentService : JobIntentService() {
    override fun onHandleWork(intent: Intent) {
    }
}


