package com.android.geofencedemo

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.android.geofencedemo.receivers.GeoFenceBroadcastReceiver
import com.android.geofencedemo.utils.GoogleLocationManager
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.OnCompleteListener


class MainActivity : AppCompatActivity() {

    lateinit var locationManagerGoogle: GoogleLocationManager

    private lateinit var geofencingClient: GeofencingClient
    private val geofenceList = ArrayList<Geofence>()
    private lateinit var pendingIntent: PendingIntent
    private val TAG = "geod Geofence"

    val PERMISSIONS = arrayOf(
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_FINE_LOCATION
    )

    var myLocation: Location? = null

    companion object {
        const val HOME_GEOFENCE_ID = "homeGeoFenceId"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // TODO: 1.5 attach locationManager, geofencingClient, pendingIntent


        if (!hasLocationPermission()) {
            requestPermission()
        }
        handleGoogleLocation()
        createGeoFenceForHome(24.6624, 46.7288, 100f)
    }

    // TODO: 1.6 get device location update
    fun handleGoogleLocation() {
    }

    fun printLocation(location: Location?) {
        Log.i(
            TAG,
            "Fetched Location: latitude: ${location?.latitude} | longitude: ${location?.longitude}"
        )
    }

    // TODO: 1.7 get PendingIntent and attached Broadcast Receiver
    private fun getPendingIntent(): PendingIntent? {
        return null
    }

    // TODO: 1.8 get GeofencingRequest, define initial triggers
    private fun getGeofencingRequest(): GeofencingRequest? {
        return null
    }

    // TODO: 1.9 Create GeoFence, make list of geofence and geofences from geofencingClient
    private fun createGeoFenceForHome(lat: Double, lon: Double, radius: Float) {

    }

    fun removeGeofence() {
        geofencingClient.removeGeofences(listOf(HOME_GEOFENCE_ID)).addOnCompleteListener {
            if (it.isSuccessful) {
                Log.i(TAG, "delete geofence with ID success!")
            } else {
                Log.w(TAG, "delete geofence with ID failed ")
            }
        }
    }

    /**
     * Determine if you have the location permission
     */
    private fun hasLocationPermission(): Boolean {
        for (permission in PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    permission
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }
        return true
    }

    fun requestPermission() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            Log.i(TAG, "sdk < 28 Q")
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
                ||
                ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                val strings = arrayOf<String>(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
                ActivityCompat.requestPermissions(this, strings, 1)
            }
        } else {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
                ||
                ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
                ||
                ActivityCompat.checkSelfPermission(
                    this,
                    "android.permission.ACCESS_BACKGROUND_LOCATION"
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                val strings = arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    "android.permission.ACCESS_BACKGROUND_LOCATION"
                )
                ActivityCompat.requestPermissions(this, strings, 1)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GoogleLocationManager.REQUEST_CHECK_SETTINGS) {
            when (resultCode) {
                Activity.RESULT_OK -> {
                    Log.d(TAG, "User confirm to access location")

                    handleGoogleLocation()
                }
                Activity.RESULT_CANCELED -> {
                    Log.d(TAG, "User denied to access location")
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.size > 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED
            ) {
                Log.i(
                    TAG, "onRequestPermissionsResult: apply LOCATION PERMISSION successful"
                )
                handleGoogleLocation()
            } else {
                Log.i(
                    TAG, "onRequestPermissionsResult: apply LOCATION PERMISSSION  failed"
                )
            }
        }
        if (requestCode == 2) {
            if (grantResults.size > 2 && grantResults[2] == PackageManager.PERMISSION_GRANTED && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED
            ) {
                Log.i(
                    TAG, "onRequestPermissionsResult: apply ACCESS_BACKGROUND_LOCATION successful"
                )
                handleGoogleLocation()
            } else {
                Log.i(
                    TAG, "onRequestPermissionsResult: apply ACCESS_BACKGROUND_LOCATION  failed"
                )
            }
        }
    }

}